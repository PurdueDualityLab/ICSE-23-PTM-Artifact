# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['icse_23_model_hub_artifact',
 'icse_23_model_hub_artifact.downloadHFTorrent',
 'icse_23_model_hub_artifact.downloadHTML',
 'icse_23_model_hub_artifact.downloadModelInformation',
 'icse_23_model_hub_artifact.malwareScanning',
 'icse_23_model_hub_artifact.measureRepositoriesWithSignedCommits',
 'icse_23_model_hub_artifact.measureVerifiedOrganizations',
 'icse_23_model_hub_artifact.modelDocumentation',
 'icse_23_model_hub_artifact.modelDownloads',
 'icse_23_model_hub_artifact.plotData',
 'icse_23_model_hub_artifact.reproducibility']

package_data = \
{'': ['*']}

install_requires = \
['bs4>=0.0.1,<0.0.2',
 'datasets>=2.4.0,<3.0.0',
 'huggingface-hub>=0.9.1,<0.10.0',
 'lxml>=4.9.1,<5.0.0',
 'matplotlib>=3.5.3,<4.0.0',
 'numpy>=1.23.2,<2.0.0',
 'opencv-python>=4.6.0,<5.0.0',
 'pandas>=1.4.3,<2.0.0',
 'progress>=1.6,<2.0',
 'requests>=2.28.1,<3.0.0',
 'tensorflow>=2.9.1,<3.0.0',
 'timm>=0.6.7,<0.7.0',
 'torch>=1.12.1,<2.0.0',
 'torchaudio>=0.12.1,<0.13.0',
 'torchmetrics>=0.9.3,<0.10.0',
 'torchvision>=0.13.1,<0.14.0',
 'tqdm>=4.64.0,<5.0.0',
 'transformers>=4.21.2,<5.0.0']

entry_points = \
{'console_scripts': ['icse-download-malware-html = '
                     'icse_23_model_hub_artifact.downloadHTML.downloadMalwareHTML:main',
                     'icse-download-model-information = '
                     'icse_23_model_hub_artifact.downloadModelInformation.main:main',
                     'icse-download-organization-list = '
                     'icse_23_model_hub_artifact.downloadHTML.downloadOrganizationList:main',
                     'icse-extract-model-downloads = '
                     'icse_23_model_hub_artifact.modelDownloads.main:main',
                     'icse-extract-model-names = '
                     'icse_23_model_hub_artifact.downloadHFTorrent.extractRepoNames:main',
                     'icse-measure-repos-with-signed-commits = '
                     'icse_23_model_hub_artifact.measureRepositoriesWithSignedCommits.main:main',
                     'icse-measure-verified-organizations = '
                     'icse_23_model_hub_artifact.measureVerifiedOrganizations.main:main',
                     'icse-plot-model-downloads = '
                     'icse_23_model_hub_artifact.modelDownloads.plot:main',
                     'icse-scan-for-malware = '
                     'icse_23_model_hub_artifact.malwareScanning.main:main']}

setup_kwargs = {
    'name': 'icse-23-model-hub-artifact',
    'version': '0.1.3',
    'description': 'Code artifacts for ICSE 2023 ',
    'long_description': 'None',
    'author': 'None',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<3.11',
}


setup(**setup_kwargs)
