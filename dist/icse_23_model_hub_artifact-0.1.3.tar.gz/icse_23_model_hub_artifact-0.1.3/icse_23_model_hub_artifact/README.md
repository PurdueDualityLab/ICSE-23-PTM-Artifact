# Scripts (Section I, IV.B)

This folder includes

- HFTorrent download scripts
- Model information download scripts
- malware scanning scripts
- Commit signing measurement
- Verified organization measurement
- Documentation measurement
- Scripts we used to get the number of package downloads
- Scipts we used to generate the figures