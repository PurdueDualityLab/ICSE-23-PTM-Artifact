'''
parse task
if no task then quit

clone model
if makes no claims then quit

parse dataset
download dataset
if no dataset then quit

eval model
compare results
'''
